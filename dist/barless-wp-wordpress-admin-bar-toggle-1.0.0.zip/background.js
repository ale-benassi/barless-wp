const DEFAULT_SETTINGS = {
  persistHiddenState: false
};
const DEFAULT_TITLE = "Toggle WordPress admin bar";
const NO_ADMIN_BAR_TITLE = "No WordPress admin bar on this page";
const SHOW_TITLE = "Show WordPress admin bar";
const HIDE_TITLE = "Hide WordPress admin bar";
const ACTION_ICONS = {
  visible: {
    16: "icons/visible-16.png",
    32: "icons/visible-32.png",
    48: "icons/visible-48.png",
    128: "icons/visible-128.png"
  },
  hidden: {
    16: "icons/hidden-16.png",
    32: "icons/hidden-32.png",
    48: "icons/hidden-48.png",
    128: "icons/hidden-128.png"
  }
};

chrome.runtime.onInstalled.addListener(async () => {
  const current = await chrome.storage.sync.get("persistHiddenState");

  if (typeof current.persistHiddenState !== "boolean") {
    await chrome.storage.sync.set(DEFAULT_SETTINGS);
  }
});

async function resolveTargetTab(clickedTab) {
  if (clickedTab?.id) {
    return clickedTab;
  }

  const [activeTab] = await chrome.tabs.query({
    active: true,
    currentWindow: true
  });

  return activeTab;
}

async function setActionAppearance(tabId, { hasAdminBar, hidden }) {
  const path = hasAdminBar && hidden ? ACTION_ICONS.hidden : ACTION_ICONS.visible;
  const title = !hasAdminBar
    ? NO_ADMIN_BAR_TITLE
    : hidden
      ? SHOW_TITLE
      : HIDE_TITLE;

  await Promise.all([
    chrome.action.setIcon({ tabId, path }),
    chrome.action.setTitle({ tabId, title })
  ]);
}

async function resetActionAppearance(tabId) {
  await Promise.all([
    chrome.action.setIcon({ tabId, path: ACTION_ICONS.visible }),
    chrome.action.setTitle({ tabId, title: DEFAULT_TITLE })
  ]);
}

chrome.action.onClicked.addListener(async (clickedTab) => {
  const targetTab = await resolveTargetTab(clickedTab);

  if (!targetTab?.id) {
    return;
  }

  try {
    const response = await chrome.tabs.sendMessage(targetTab.id, { type: "TOGGLE_ADMIN_BAR" });

    if (response?.ok) {
      await setActionAppearance(targetTab.id, response);
    }
  } catch (error) {
    // Ignore pages where Chrome does not allow content scripts or no receiver exists.
  }
});

chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type !== "ADMIN_BAR_STATE" || !sender.tab?.id) {
    return;
  }

  void setActionAppearance(sender.tab.id, message);
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status !== "loading") {
    return;
  }

  void resetActionAppearance(tabId);
});
